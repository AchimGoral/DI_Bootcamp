from django.apps import AppConfig


class RentalConfig(AppConfig):
    name = 'rental'
